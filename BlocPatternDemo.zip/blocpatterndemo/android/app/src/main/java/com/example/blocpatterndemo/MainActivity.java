package com.example.blocpatterndemo;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
